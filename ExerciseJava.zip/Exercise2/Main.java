import java.util.Scanner;

class Main {
  public static void main(String[] args)
  {
	  Scanner sc1;
	  Scanner sc2;
	  sc1=new Scanner(System.in);
	  sc2=new Scanner(System.in);
	  System.out.println("Please enter type of conversion: MetersToYards/DollarToEuro/CelsiusToFahrenheit/MetersToMiles ");
	  
	  String conversion = sc1.next();
	  System.out.println(conversion);
	  System.out.println("Please enter value to convert: ");
	  
	  String value = sc2.next();
	 sc2.close();

    if(conversion=="MetersToYards")
    {
    	UnitConverter myConverter = new MetersToYards();
        double meters = Double.parseDouble(value);
        double yards = myConverter.convert(meters);	
        System.out.println(myConverter.toString() + " has converted " + meters + " m to " + yards + " yd");
    }
    else if (conversion=="DollarToEuro")
    {
    	UnitConverter myConverter = new DollarToEuroConverter();
        double aLotOfDollars = Double.parseDouble(value);
        double aLotOfEuros = myConverter.convert(aLotOfDollars);
        System.out.println(myConverter.toString() + " has converted " + aLotOfDollars + " USD to " + aLotOfEuros + " EUR!");
	}
    else if (conversion=="CelsiusToFahrenheit")
    {
    	UnitConverter myConverter = new CelsiusToFahrenheitConverter();
        double Celsius = Double.parseDouble(value);
        double Fahrenheit = myConverter.convert(Celsius);
        System.out.println(myConverter.toString() + " has converted " + Celsius + " degree to " + Fahrenheit + " F");
	}
    else if (conversion=="MetersToMiles")
    {
    	UnitConverter myConverter = new MetersToMilesConverter();
        double meter = Double.parseDouble(value);
        double miles = myConverter.convert(meter);
        System.out.println(myConverter.toString() + " has converted " + meter + " m to " + miles + " mi");
	}
    else
    	System.out.println("not available");
    
    sc1.close();
    /*
     * TODO
     *
     * use desired conversion here
     *
    */

      }
}
