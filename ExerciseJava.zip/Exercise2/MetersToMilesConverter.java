
public class MetersToMilesConverter extends LengthConverter {
	public MetersToMilesConverter() { }

	  public double convert(double inLength) {
	    return inLength * 0.00062137;
	  }
	  
	  public String toString(){
		    return "Meters to Miles Converter";
		  }

		  public void print(){
		    System.out.println(toString());
		  }
}
