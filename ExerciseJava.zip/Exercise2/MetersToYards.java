
public class MetersToYards extends LengthConverter {
	public MetersToYards() { }

	  public double convert(double inLength) {
	    return inLength /0.9144;
	  }
	  
	  public String toString(){
		    return "Meters to Yards Converter";
		  }

		  public void print(){
		    System.out.println(toString());
		  }
}
