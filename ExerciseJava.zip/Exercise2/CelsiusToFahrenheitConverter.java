
public class CelsiusToFahrenheitConverter extends TemperatureConverter {
	public CelsiusToFahrenheitConverter() { }

	  public double convert(double inTemp) {
	    return inTemp * 9/5 + 32;
	  }
	  
	  public String toString(){
		    return "Celsius to Fahrenheit Converter";
		  }

		  public void print(){
		    System.out.println(toString());
		  }
}
