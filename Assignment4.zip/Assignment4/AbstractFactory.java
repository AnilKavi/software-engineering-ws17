
public abstract class AbstractFactory {
	
	abstract UnitConverter Create(String str);
}
